
userName = input()

print("Hello",userName,"and welcome to CS Online!")

